const express = require("express");
const session = require("express-session");
const pgSession = require("connect-pg-simple")(session);
const { Pool } = require("pg");
const bcrypt = require("bcryptjs");
const multer = require("multer");
const path = require("path");
const fs = require("fs");

const app = express();
const PORT = process.env.PORT || 3000;
const DATABASE_URL = process.env.DATABASE_URL;
if (!DATABASE_URL) throw new Error("DATABASE_URL is required");
if (!process.env.SESSION_SECRET) throw new Error("SESSION_SECRET is required");

const pool = new Pool({
  connectionString: DATABASE_URL,
  ssl: process.env.NODE_ENV === "production" ? { rejectUnauthorized: false } : false
});

const uploadDir = process.env.UPLOAD_DIR || path.join(__dirname, "uploads");
fs.mkdirSync(uploadDir, { recursive: true });

async function initDb() {
  await pool.query(`
    CREATE TABLE IF NOT EXISTS users (
      id SERIAL PRIMARY KEY,
      name VARCHAR(120) NOT NULL,
      email VARCHAR(255) UNIQUE NOT NULL,
      password_hash TEXT NOT NULL,
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    );
    CREATE TABLE IF NOT EXISTS products (
      id SERIAL PRIMARY KEY,
      user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      name VARCHAR(120) NOT NULL,
      description TEXT NOT NULL DEFAULT '',
      price NUMERIC(12,2) NOT NULL CHECK(price >= 0),
      category VARCHAR(80) NOT NULL DEFAULT 'სხვა',
      image TEXT,
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    );
    CREATE TABLE IF NOT EXISTS comments (
      id SERIAL PRIMARY KEY,
      product_id INTEGER NOT NULL REFERENCES products(id) ON DELETE CASCADE,
      user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      comment TEXT NOT NULL,
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    );
    CREATE TABLE IF NOT EXISTS ratings (
      id SERIAL PRIMARY KEY,
      product_id INTEGER NOT NULL REFERENCES products(id) ON DELETE CASCADE,
      user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      rating INTEGER NOT NULL CHECK(rating BETWEEN 1 AND 5),
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
      UNIQUE(product_id,user_id)
    );
  `);
}

app.disable("x-powered-by");
app.use(express.json({limit:"1mb"}));
app.use(express.urlencoded({extended:true}));
app.use(session({
  store: new pgSession({pool, tableName:"user_sessions", createTableIfMissing:true}),
  secret: process.env.SESSION_SECRET,
  resave:false,
  saveUninitialized:false,
  cookie:{httpOnly:true, sameSite:"lax", secure:process.env.NODE_ENV==="production", maxAge:7*24*60*60*1000}
}));
app.use("/uploads", express.static(uploadDir));
app.use((req,res,next)=>{
  res.setHeader("X-Content-Type-Options","nosniff");
  res.setHeader("X-Frame-Options","DENY");
  res.setHeader("Referrer-Policy","strict-origin-when-cross-origin");
  next();
});
app.use(express.static(path.join(__dirname,"public")));

const storage = multer.diskStorage({
  destination: (_,__,cb)=>cb(null,uploadDir),
  filename: (_,file,cb)=>{
    const ext=path.extname(file.originalname).toLowerCase();
    cb(null,`${Date.now()}-${Math.random().toString(36).slice(2)}${ext}`);
  }
});
const upload=multer({
  storage,
  limits:{fileSize:5*1024*1024, files:1},
  fileFilter:(_,file,cb)=>{
    const allowed=["image/jpeg","image/png","image/webp","image/gif"];
    cb(allowed.includes(file.mimetype)?null:new Error("მხოლოდ JPG, PNG, WEBP ან GIF ფაილია დაშვებული"), allowed.includes(file.mimetype));
  }
});

async function me(req){
  if(!req.session.userId) return null;
  const {rows}=await pool.query("SELECT id,name,email,created_at FROM users WHERE id=$1",[req.session.userId]);
  return rows[0]||null;
}
async function auth(req,res,next){
  if(!await me(req)) return res.status(401).json({error:"ავტორიზაცია საჭიროა"});
  next();
}

app.get("/api/me",async(req,res)=>res.json({user:await me(req)}));

app.post("/api/register",async(req,res)=>{
  try{
    const name=String(req.body.name||"").trim();
    const email=String(req.body.email||"").trim().toLowerCase();
    const password=String(req.body.password||"");
    if(name.length<2) return res.status(400).json({error:"სახელი მინიმუმ 2 სიმბოლოა"});
    if(!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return res.status(400).json({error:"ელფოსტა არასწორია"});
    if(password.length<6) return res.status(400).json({error:"პაროლი მინიმუმ 6 სიმბოლოა"});
    const hash=await bcrypt.hash(password,12);
    const {rows}=await pool.query("INSERT INTO users(name,email,password_hash) VALUES($1,$2,$3) RETURNING id",[name,email,hash]);
    req.session.userId=rows[0].id;
    res.json({user:await me(req)});
  }catch(e){
    if(e.code==="23505") return res.status(409).json({error:"ეს ელფოსტა უკვე რეგისტრირებულია"});
    res.status(500).json({error:"რეგისტრაციის შეცდომა"});
  }
});

app.post("/api/login",async(req,res)=>{
  const email=String(req.body.email||"").trim().toLowerCase();
  const password=String(req.body.password||"");
  const {rows}=await pool.query("SELECT * FROM users WHERE email=$1",[email]);
  if(!rows[0]||!(await bcrypt.compare(password,rows[0].password_hash))) return res.status(401).json({error:"ელფოსტა ან პაროლი არასწორია"});
  req.session.userId=rows[0].id;
  res.json({user:await me(req)});
});

app.post("/api/logout",(req,res)=>req.session.destroy(()=>res.json({ok:true})));

app.get("/api/products",async(req,res)=>{
  const q=String(req.query.q||"").trim();
  const category=String(req.query.category||"").trim();
  const params=[]; const where=[];
  if(q){params.push(`%${q}%`); const n=params.length; params.push(`%${q}%`,`%${q}%`); where.push(`(p.name ILIKE $${n} OR p.description ILIKE $${n+1} OR p.category ILIKE $${n+2})`);}
  if(category){params.push(category);where.push(`p.category=$${params.length}`);}
  const sql=`SELECT p.*,u.name seller,COALESCE(ROUND(AVG(r.rating),1),0) average_rating,COUNT(DISTINCT r.id) rating_count,COUNT(DISTINCT c.id) comment_count
    FROM products p JOIN users u ON u.id=p.user_id LEFT JOIN ratings r ON r.product_id=p.id LEFT JOIN comments c ON c.product_id=p.id
    ${where.length?"WHERE "+where.join(" AND "):""} GROUP BY p.id,u.name ORDER BY p.id DESC`;
  const {rows}=await pool.query(sql,params); res.json({products:rows});
});

app.get("/api/products/:id",async(req,res)=>{
  const id=Number(req.params.id);
  const p=await pool.query(`SELECT p.*,u.name seller,COALESCE(ROUND(AVG(r.rating),1),0) average_rating,COUNT(DISTINCT r.id) rating_count
    FROM products p JOIN users u ON u.id=p.user_id LEFT JOIN ratings r ON r.product_id=p.id WHERE p.id=$1 GROUP BY p.id,u.name`,[id]);
  if(!p.rows[0]) return res.status(404).json({error:"პროდუქტი ვერ მოიძებნა"});
  const c=await pool.query(`SELECT c.id,c.comment,c.created_at,u.name author FROM comments c JOIN users u ON u.id=c.user_id WHERE c.product_id=$1 ORDER BY c.id DESC`,[id]);
  res.json({product:p.rows[0],comments:c.rows});
});

app.post("/api/products",auth,upload.single("image"),async(req,res)=>{
  const name=String(req.body.name||"").trim(),description=String(req.body.description||"").trim(),category=String(req.body.category||"სხვა").trim(),price=Number(req.body.price);
  if(name.length<2||name.length>120||description.length>5000||category.length>80||!Number.isFinite(price)||price<0||price>999999999) return res.status(400).json({error:"პროდუქტის მონაცემები არასწორია"});
  const image=req.file?`/uploads/${req.file.filename}`:null;
  const {rows}=await pool.query("INSERT INTO products(user_id,name,description,price,category,image) VALUES($1,$2,$3,$4,$5,$6) RETURNING id",[req.session.userId,name,description,price,category,image]);
  res.json({id:rows[0].id});
});

app.delete("/api/products/:id",auth,async(req,res)=>{
  const {rowCount}=await pool.query("DELETE FROM products WHERE id=$1 AND user_id=$2",[Number(req.params.id),req.session.userId]);
  if(!rowCount)return res.status(403).json({error:"პროდუქტის წაშლის უფლება არ გაქვს"});
  res.json({ok:true});
});

app.post("/api/products/:id/comments",auth,async(req,res)=>{
  const comment=String(req.body.comment||"").trim();
  if(!comment||comment.length>1000)return res.status(400).json({error:"კომენტარი აუცილებელია"});
  await pool.query("INSERT INTO comments(product_id,user_id,comment) VALUES($1,$2,$3)",[Number(req.params.id),req.session.userId,comment]);
  res.json({ok:true});
});

app.post("/api/products/:id/rating",auth,async(req,res)=>{
  const rating=Number(req.body.rating);
  if(!Number.isInteger(rating)||rating<1||rating>5)return res.status(400).json({error:"შეფასება 1-5 უნდა იყოს"});
  await pool.query(`INSERT INTO ratings(product_id,user_id,rating) VALUES($1,$2,$3)
    ON CONFLICT(product_id,user_id) DO UPDATE SET rating=EXCLUDED.rating,created_at=NOW()`,[Number(req.params.id),req.session.userId,rating]);
  res.json({ok:true});
});

app.get("/api/my-products",auth,async(req,res)=>{
  const {rows}=await pool.query(`SELECT p.*,COALESCE(ROUND(AVG(r.rating),1),0) average_rating,COUNT(r.id) rating_count
    FROM products p LEFT JOIN ratings r ON r.product_id=p.id WHERE p.user_id=$1 GROUP BY p.id ORDER BY p.id DESC`,[req.session.userId]);
  res.json({products:rows});
});

app.get(/.*/,(_,res)=>res.sendFile(path.join(__dirname,"public","index.html")));

app.use((err,req,res,next)=>{
  console.error(err);
  if(err instanceof multer.MulterError || err.message?.includes("JPG")) return res.status(400).json({error:err.message||"სურათის ატვირთვა ვერ მოხერხდა"});
  res.status(500).json({error:"სერვერის შეცდომა"});
});

initDb().then(()=>app.listen(PORT,()=>console.log("MyShop running on port "+PORT))).catch(err=>{console.error(err);process.exit(1)});
