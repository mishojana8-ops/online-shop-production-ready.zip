# MyShop — გაუმჯობესებული ვერსია

ეს არის production-ready ონლაინ-მაღაზიის გაუმჯობესებული ვერსია Node.js + Express + PostgreSQL-ით.

## გაუმჯობესებები
- თანამედროვე, responsive UI მობილურისთვისაც.
- გაუმჯობესებული პროდუქტის ბარათები და დეტალების modal.
- lazy-loaded სურათები და ალტ-ტექსტები.
- toast შეტყობინებები `alert()`-ის ნაცვლად.
- უკეთესი ფორმების validation და UX.
- Express 5-ის თავსებადი SPA fallback (`/.*/`).
- აუცილებელი `SESSION_SECRET` შემოწმება.
- უსაფრთხოების საბაზისო HTTP headers.
- upload-ის ტიპისა და ზომის კონტროლი.
- პროდუქტის სახელის/აღწერის/კატეგორიის ზომების კონტროლი.
- keyboard-friendly modal (`Escape`) და accessibility labels.
- სურათების 5MB ლიმიტი და დაშვებული ფორმატები.

## გაშვება

საჭიროა Node.js 20+ და PostgreSQL.

გარემოს ცვლადები:
- `DATABASE_URL`
- `SESSION_SECRET`
- `NODE_ENV=production` production გარემოში
- სურვილისამებრ `PORT`, `UPLOAD_DIR`

შემდეგ:

```bash
npm install
npm start
```

შენიშვნა: რეალურ production გარემოში რეკომენდებულია upload-ების object storage-ზე (მაგ. S3-compatible storage) გადატანა და reverse proxy/TLS გამოყენება.
